# Examples of Ansible playbooks to automate server installations

Before running playbooks, make sure 

1. the IP addresses/FQDNs of the servers are updated in the relevant inventory file (e.g. in `rke2/inventory.ini` if installing RKE2)
2. the SSH key is added to the servers and matches the key in ansible.cfg
3. You have Ansible installed on your machine with e.g. `pip install ansible`

## high-availability RKE2 cluster deployment using Ansible

In `ansible-notebooks` directory run the following command:

`ansible-playbook -i rke2/inventory.ini rke2/rke2.yaml`

The playbook will install RKE2 on the servers and configure a high-availability cluster. It will also fetch the kubeconfig file from the first server and save it in your present working directory as `kubeconfig_rke2.yaml`. You can use this file to access the cluster using `kubectl` after running `export KUBECONFIG=kubeconfig_rke2.yaml`

## Installation of ROCM drivers

In `ansible-notebooks` directory run the following command:

`ansible-playbook -i rocm/inventory.ini rocm/install-rocm-host-driver.yaml`
